package wbdavenp_CSCI201L_Assignment1;

public class Students {
	private int numGrades;
	private double average;
	
	public class name{
		String fname;
		String lname;
	}
	
	
}
